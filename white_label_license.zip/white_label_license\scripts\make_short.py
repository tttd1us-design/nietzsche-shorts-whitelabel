"""YouTube Shorts 제작 파이프라인.

script.json(대본) -> TTS 음성 -> 스톡 영상 -> 자막 -> 1080x1920 final.mp4

사용법:
    python scripts/make_short.py examples/sample_script.json
    python scripts/make_short.py my_script.json --no-bgm --voice ko-KR-InJoonNeural
"""
from __future__ import annotations

import argparse
import asyncio
import datetime as dt
import json
import os
import random
import re
import shutil
import subprocess
import sys
from pathlib import Path

import edge_tts
import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / "config" / ".env")

W, H, FPS = 1080, 1920, 30
DEFAULT_VOICE = os.getenv("SHORTS_VOICE", "ko-KR-SunHiNeural")
DEFAULT_RATE = os.getenv("SHORTS_RATE", "+10%")
PEXELS_KEY = os.getenv("PEXELS_API_KEY", "").strip()
FONT_NAME = "Malgun Gothic"
BG_COLORS = ["0x2563eb", "0x7c3aed", "0x0891b2", "0x0d9488", "0xd97706", "0xdb2777"]  # 그라데이션 배경용(너무 어둡지 않게)

# Windows 콘솔에서 한글 출력이 깨지지 않도록
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")


def log(msg: str) -> None:
    print(f"[shorts] {msg}", flush=True)


# ---------------------------------------------------------------- ffmpeg
def find_tool(name: str) -> str:
    env = os.getenv(name.upper())
    if env and Path(env).exists():
        return env
    found = shutil.which(name)
    if found:
        return found
    hermes_home = Path(os.getenv("HERMES_HOME", r"D:\hermes"))
    for p in hermes_home.rglob(f"{name}.exe"):
        return str(p)
    sys.exit(f"{name}을(를) 찾을 수 없습니다. FFmpeg를 설치하거나 config/.env에 {name.upper()}=경로 를 지정하세요.")


FFMPEG = find_tool("ffmpeg")
FFPROBE = find_tool("ffprobe")


def run(cmd: list[str], cwd: Path | None = None) -> None:
    proc = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        sys.exit(f"명령 실패: {' '.join(cmd[:6])} ...\n{proc.stderr[-2000:]}")


def duration_of(path: Path) -> float:
    out = subprocess.run(
        [FFPROBE, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)],
        capture_output=True, text=True,
    ).stdout.strip()
    return float(out)


# ---------------------------------------------------------------- TTS
async def _tts(text: str, voice: str, rate: str, out: Path) -> list[dict]:
    words: list[dict] = []
    comm = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
    with open(out, "wb") as f:
        async for chunk in comm.stream():
            if chunk["type"] == "audio":
                f.write(chunk["data"])
            elif chunk["type"] == "WordBoundary":
                words.append({
                    "start": chunk["offset"] / 1e7,
                    "end": (chunk["offset"] + chunk["duration"]) / 1e7,
                    "text": chunk["text"],
                })
    return words


def tts(text: str, voice: str, rate: str, out: Path) -> list[dict]:
    for attempt in range(3):
        try:
            return asyncio.run(_tts(text, voice, rate, out))
        except Exception as e:  # 네트워크 일시 오류 재시도
            log(f"TTS 재시도 {attempt + 1}/3: {e}")
    sys.exit("TTS 생성에 실패했습니다. 인터넷 연결을 확인하세요.")


# ---------------------------------------------------------------- 스톡 영상
def fetch_pexels(query: str, dest: Path, used: set[int]) -> Path | None:
    if not PEXELS_KEY:
        return None
    try:
        r = requests.get(
            "https://api.pexels.com/videos/search",
            headers={"Authorization": PEXELS_KEY},
            params={"query": query, "orientation": "portrait", "per_page": 15},
            timeout=20,
        )
        r.raise_for_status()
        videos = [v for v in r.json().get("videos", []) if v["id"] not in used]
    except Exception as e:
        log(f"Pexels 검색 실패({query}): {e}")
        return None
    random.shuffle(videos)
    for v in videos:
        files = [f for f in v["video_files"] if f.get("height") and f["height"] >= 1280 and f["height"] > f["width"]]
        if not files:
            continue
        best = min(files, key=lambda f: abs(f["height"] - H))
        try:
            with requests.get(best["link"], stream=True, timeout=60) as resp:
                resp.raise_for_status()
                with open(dest, "wb") as fh:
                    for part in resp.iter_content(1 << 20):
                        fh.write(part)
            used.add(v["id"])
            return dest
        except Exception as e:
            log(f"영상 다운로드 실패: {e}")
    return None


OPENVERSE_TIERS = ["stocksnap,wordpress", "flickr,wikimedia,rawpixel"]  # 실사 사진 출처 우선
NOT_PHOTO = re.compile(r"drawing|print|illustrat|painting|engraving|plate|manuscript|scroll|sketch|woodcut|"
                       r"lithograph|poster|diagram|map|book|page|ukiyo|vintage|etching|clipart|vector|icon", re.I)


def _openverse_search(query: str, sources: str) -> list[dict]:
    r = requests.get(
        "https://api.openverse.org/v1/images/",
        params={"q": query, "license": "cc0,pdm", "category": "photograph", "source": sources,
                "size": "large", "page_size": 20, "mature": "false"},
        timeout=20,
    )
    r.raise_for_status()
    out = []
    for x in r.json().get("results", []):
        text = f"{x.get('title') or ''} {x.get('creator') or ''} " + " ".join(t["name"] for t in x.get("tags") or [])
        if NOT_PHOTO.search(text) or "BioDivLibrary" in (x.get("creator") or ""):
            continue
        out.append(x)
    return out


def fetch_openverse(query: str, dest_stem: Path, used: set) -> Path | None:
    """키 없이 쓸 수 있는 CC0/퍼블릭 도메인 실사 사진(Openverse)."""
    results: list[dict] = []
    for sources in OPENVERSE_TIERS:
        try:
            results = [x for x in _openverse_search(query, sources) if x["id"] not in used]
        except Exception as e:
            log(f"Openverse 검색 실패({query}): {e}")
        if results:
            break
    if not results:
        return None
    # 세로로 긴 사진을 우선(9:16으로 잘라도 덜 잘림), 상위권 안에서 무작위
    results = results[:12]
    random.shuffle(results)
    results.sort(key=lambda x: (x.get("height") or 1) / (x.get("width") or 1), reverse=True)
    for item in results[:6]:
        try:
            resp = requests.get(item["url"], timeout=30, headers={"User-Agent": "shorts-bot/1.0"})
            resp.raise_for_status()
            if not resp.headers.get("content-type", "").startswith("image/") or len(resp.content) < 30_000:
                continue
            dest = dest_stem.with_suffix(".jpg")
            dest.write_bytes(resp.content)
            used.add(item["id"])
            CREDITS.append(f"{item.get('title') or 'image'} — {item.get('creator') or 'unknown'} ({item['license'].upper()}) {item.get('foreign_landing_url', '')}")
            return dest
        except Exception:
            continue
    return None


CREDITS: list[str] = []


class MissingMedia(Exception):
    pass





def brightness(clip: Path) -> float:
    """클립 중간 프레임의 평균 밝기(0~255)."""
    r = subprocess.run([FFMPEG, "-v", "error", "-i", str(clip), "-vf", "signalstats,metadata=print:key=lavfi.signalstats.YAVG",
                        "-frames:v", "15", "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    vals = [float(v) for v in re.findall(r"YAVG=([\d.]+)", r.stderr + r.stdout)]
    return sum(vals) / len(vals) if vals else -1


def make_scene_video(scene: dict, idx: int, dur: float, work: Path, used: set,
                     image_style: str = "", strict: bool = True) -> Path:
    out = work / f"scene_{idx:02d}.mp4"
    bw, bh = W, H
    vf = f"scale={bw}:{bh}:force_original_aspect_ratio=increase,crop={bw}:{bh},fps={FPS},setsar=1"
    src: Path | None = None

    local = scene.get("media")
    if local and Path(local).exists():
        src = Path(local)
    if not src and scene.get("image_prompt"):
        from gen_image import generate
        prompt = f"{image_style}. {scene['image_prompt']}" if image_style else scene["image_prompt"]
        provider = generate(prompt, work / f"gen_{idx:02d}.jpg", "9:16", seed=idx + 1)
        if provider:
            src = work / f"gen_{idx:02d}.jpg"
            log(f"장면 {idx + 1}: 이미지 생성 ({provider})")
            if provider == "pollinations":
                CREDITS.append("Illustration generated with Pollinations.ai")
    if not src:
        queries = scene.get("keywords", []) or []
        for q in queries:
            src = fetch_pexels(q, work / f"raw_{idx:02d}.mp4", used)
            if src:
                break
        if not src:
            for q in queries:
                src = fetch_openverse(q, work / f"raw_{idx:02d}", used)
                if src:
                    log(f"장면 {idx + 1}: 무료 사진 사용 ({q})")
                    break

    # 장면 클립은 중간 파일이므로 ultrafast (최종 인코딩에서 다시 압축됨)
    tmp_enc = ["-an", "-c:v", "libx264", "-preset", "ultrafast", "-crf", "20", "-pix_fmt", "yuv420p", str(out)]
    if src and src.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}:
        # 시네마틱 컬러 그레이딩 + 미세 비기(vignette) + 동적 줌인 속도감 향상
        run([FFMPEG, "-y", "-loop", "1", "-i", str(src), "-t", f"{dur:.3f}", "-vf",
             f"scale={bw}*2:{bh}*2:force_original_aspect_ratio=increase,crop={bw}:{bh},"
             f"zoompan=z='min(zoom+0.002,1.15)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={int(dur * FPS) + 1}:s={bw}x{bh}:fps={FPS},"
             f"eq=contrast=1.18:saturation=1.2:gamma=0.92,vignette=PI/4,setsar=1", *tmp_enc])
    elif src:
        run([FFMPEG, "-y", "-stream_loop", "-1", "-i", str(src), "-t", f"{dur:.3f}", "-vf",
             f"{vf},eq=contrast=1.12:saturation=1.15:gamma=0.95", *tmp_enc])
    elif strict:
        raise MissingMedia(idx + 1)
    else:
        # allow_fallback일 때만: 검은 화면 대신 천천히 움직이는 컬러 그라데이션
        c0, c1 = BG_COLORS[idx % len(BG_COLORS)], BG_COLORS[(idx + 2) % len(BG_COLORS)]
        log(f"경고: 장면 {idx + 1} 영상/사진 소스 없음 → 그라데이션 배경")
        run([FFMPEG, "-y", "-f", "lavfi", "-i",
             f"gradients=s={bw}x{bh}:r={FPS}:d={dur:.3f}:c0={c0}:c1={c1}:x0=0:y0=0:x1={bw}:y1={bh}:speed=0.008",
             "-vf", f"vignette=PI/5,setsar=1", *tmp_enc])
    return out


def make_title_bar(title: str, highlights: list[str], out: Path, font: Path, is_full: bool = True) -> tuple[int, int]:
    """상단 라운드 박스 타이틀 PNG(형광 노랑 키워드 강조). (높이, y위치) 반환."""
    from PIL import Image, ImageDraw, ImageFont
    f = ImageFont.truetype(str(font), 64)
    maxw, padx, pady, gap = 900, 44, 30, 14
    tokens = title.split()
    lines, cur = [], []
    for t in tokens:  # 단어 단위 줄바꿈(최대 2줄)
        trial = " ".join(cur + [t])
        if cur and f.getlength(trial) > maxw:
            lines.append(cur)
            cur = [t]
        else:
            cur.append(t)
    lines.append(cur)
    lines = lines[:2]
    lh = 64 + 18
    bw = int(min(maxw, max(f.getlength(" ".join(l)) for l in lines))) + padx * 2
    bh = lh * len(lines) + pady * 2 - 18
    img = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    bg_color = (17, 17, 17, 200) if is_full else (255, 255, 255, 245)
    text_color = (255, 255, 255, 255) if is_full else (17, 17, 17, 255)
    d.rounded_rectangle([0, 0, bw - 1, bh - 1], radius=36, fill=bg_color)
    hl = [h for h in highlights if h]
    for li, words in enumerate(lines):
        x = (bw - f.getlength(" ".join(words))) / 2
        y = pady + li * lh
        for wi, wd in enumerate(words):
            ww = f.getlength(wd)
            if any(h in wd for h in hl):
                d.rounded_rectangle([x - 6, y + 4, x + ww + 6, y + 72], radius=10, fill=(255, 230, 0, 255))
                d.text((x, y), wd, font=f, fill=(17, 17, 17, 255))
            else:
                d.text((x, y), wd, font=f, fill=text_color)
            x += ww + f.getlength(" ")
    img.save(out)
    ytop = 240
    return bh, ytop


def make_preview(final: Path, total: float, out: Path, limit_mb: float = 5.0) -> Path:
    """텔레그램 전송용 경량본(기본 5MB 미만, 720x1280)."""
    br = int((limit_mb * 0.9 * 8 * 1024) / max(total, 1)) - 96
    for _ in range(3):
        br = max(250, min(br, 2500))
        run([FFMPEG, "-y", "-i", str(final), "-vf", "scale=720:1280", "-c:v", "libx264", "-preset", "veryfast",
             "-b:v", f"{br}k", "-maxrate", f"{int(br * 1.2)}k", "-bufsize", f"{br * 2}k",
             "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", str(out)])
        if out.stat().st_size < limit_mb * 1024 * 1024:
            break
        br = int(br * 0.75)
    return out


# ---------------------------------------------------------------- 자막(ASS)
def ass_time(t: float) -> str:
    t = max(t, 0)
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:05.2f}"


def ass_escape(text: str) -> str:
    return text.replace("\\", "").replace("{", "(").replace("}", ")").replace("\n", " ")


def chunk_words(words: list[dict], text: str, dur: float, max_chars: int = 12) -> list[tuple[float, float, str]]:
    """단어 타이밍을 화면에 보기 좋은 짧은 자막 덩어리로 묶는다."""
    if not words:  # 타이밍 정보가 없으면 글자 수 비례로 분할
        tokens = text.split()
        groups, cur = [], ""
        for tok in tokens:
            if cur and len(cur) + len(tok) + 1 > max_chars:
                groups.append(cur)
                cur = tok
            else:
                cur = f"{cur} {tok}".strip()
        if cur:
            groups.append(cur)
        total = sum(len(g) for g in groups) or 1
        res, t = [], 0.0
        for g in groups:
            d = dur * len(g) / total
            res.append((t, t + d, g))
            t += d
        return res

    res, cur, start = [], "", words[0]["start"]
    for i, w in enumerate(words):
        piece = w["text"].strip()
        if cur and len(cur) + len(piece) + 1 > max_chars:
            res.append([start, w["start"], cur])
            cur, start = piece, w["start"]
        else:
            cur = f"{cur} {piece}".strip()
        if re.search(r"[.!?。…]$", piece) and i < len(words) - 1:
            res.append([start, words[i + 1]["start"], cur])
            cur, start = "", words[i + 1]["start"]
    if cur:
        res.append([start, dur, cur])
    # 끊김 없이 이어지도록 끝 시간 보정
    for i in range(len(res) - 1):
        res[i][1] = res[i + 1][0]
    return [tuple(r) for r in res if r[2]]


def write_ass(path: Path, title: str, cues: list[tuple[float, float, str]], total: float, show_title: bool,
              layout: str = "full") -> None:
    # Full 9:16 layout: 자막을 화면 중앙 하단에 배치 (alignment=2, MarginV=280)
    sub_align, sub_mv = 2, 280
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Sub,{FONT_NAME},88,&H00FFFFFF,&H0000FFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,2,{sub_align},70,70,{sub_mv},1
Style: Hi,{FONT_NAME},88,&H0000E6FF,&H0000FFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,2,{sub_align},70,70,{sub_mv},1
Style: Title,{FONT_NAME},72,&H0000FFFF,&H00FFFFFF,&H00000000,&HC0000000,-1,0,0,0,100,100,0,0,3,14,2,8,60,60,250,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    lines = []
    # Full layout에서는 타이틀바가 영상 자체에 합성되므로, ASS 자막으로는 타이틀을 출력하지 않음.
    # if show_title and title:
    #     lines.append(f"Dialogue: 1,{ass_time(0)},{ass_time(total)},Title,,0,0,0,,{ass_escape(title)}")
    for i, (s, e, txt) in enumerate(cues):
        style = "Hi" if i % 4 == 0 else "Sub"  # 리듬감 있게 가끔 노란색 강조
        pop = r"{\fscx80\fscy80\t(0,90,\fscx105\fscy105)\t(90,160,\fscx100\fscy100)}"
        lines.append(f"Dialogue: 0,{ass_time(s)},{ass_time(e)},{style},,0,0,0,,{pop}{ass_escape(txt)}")
    path.write_text(header + "\n".join(lines) + "\n", encoding="utf-8-sig")


# ---------------------------------------------------------------- 메인
def slugify(text: str) -> str:
    s = re.sub(r"[^\w가-힣]+", "_", text).strip("_")
    return s[:40] or "short"


def pick_bgm(name: str | None) -> Path | None:
    music_dir = ROOT / "assets" / "music"
    if name:
        p = Path(name) if Path(name).is_absolute() else music_dir / name
        return p if p.exists() else None
    tracks = [p for p in music_dir.iterdir() if p.suffix.lower() in {".mp3", ".wav", ".m4a", ".ogg"}]
    return random.choice(tracks) if tracks else None


def build(script_path: Path, voice: str | None, rate: str | None, use_bgm: bool, out_root: Path,
          allow_fallback: bool = False) -> Path:
    data = json.loads(script_path.read_text(encoding="utf-8"))
    scenes = data.get("scenes") or []
    if not scenes:
        sys.exit("script.json에 scenes가 비어 있습니다.")
    title = data.get("title", "제목 없음")
    voice = voice or data.get("voice") or DEFAULT_VOICE
    rate = rate or data.get("rate") or DEFAULT_RATE
    layout = "full" # Always full layout now
    strict = not (allow_fallback or data.get("allow_fallback", False))

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = out_root / f"{stamp}_{slugify(title)}"
    work = outdir / "work"
    (work / "fonts").mkdir(parents=True, exist_ok=True)
    font = ROOT / "assets" / "fonts" / "malgunbd.ttf"
    if not font.exists():  # 저장소에는 글꼴을 넣지 않으므로 Windows 기본 글꼴 사용
        font = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts" / "malgunbd.ttf"
    shutil.copy(font, work / "fonts" / "malgunbd.ttf")
    # 추가 폰트(Pretendard, Noto Sans KR): 대본 "font" 값으로 선택
    for extra in (ROOT / "assets" / "fonts").rglob("*"):
        if extra.suffix.lower() in {".ttf", ".otf"} and extra.name != "malgunbd.ttf":
            shutil.copy(extra, work / "fonts" / extra.name)
    global FONT_NAME
    FONT_NAME = data.get("font", FONT_NAME)
    title_font = work / "fonts" / ("Pretendard-ExtraBold.otf" if "Pretendard" in FONT_NAME and (work / "fonts" / "Pretendard-ExtraBold.otf").exists() else "malgunbd.ttf")
    shutil.copy(script_path, outdir / "script.json")

    log(f"제목: {title} / 음성: {voice} / 장면 {len(scenes)}개")
    cues: list[tuple[float, float, str]] = []
    scene_videos, scene_audios = [], []
    used: set[int] = set()
    missing: list[int] = []
    dark: list[dict] = []
    t0 = 0.0
    pad = 0.25  # 장면 사이 숨 고르기

    for i, sc in enumerate(scenes):
        text = sc["text"].strip()
        mp3 = work / f"voice_{i:02d}.mp3"
        log(f"장면 {i + 1}/{len(scenes)} 음성 생성: {text[:30]}...")
        words = tts(text, voice, rate, mp3)
        wav = work / f"voice_{i:02d}.wav"
        run([FFMPEG, "-y", "-i", str(mp3), "-af", f"apad=pad_dur={pad}", "-ar", "44100", "-ac", "2", str(wav)])
        dur = duration_of(wav)
        for s, e, txt in chunk_words(words, text, dur - pad):
            cues.append((t0 + s, t0 + e, txt))
        log(f"장면 {i + 1} 영상 준비 ({dur:.1f}초)")
        try:
            clip = make_scene_video(sc, i, dur, work, used, data.get("image_style", ""), strict)
        except MissingMedia as e:
            missing.append(int(str(e)))
            t0 += dur
            continue
        lum = brightness(clip)
        if 0 <= lum < 50:
            dark.append({"scene": i + 1, "brightness": round(lum, 1)})
            log(f"경고: 장면 {i + 1} 평균 밝기 {lum:.0f} (<50) — 너무 어둡습니다")
        scene_videos.append(clip)
        scene_audios.append(wav)
        t0 += dur

    if missing:
        shutil.rmtree(outdir, ignore_errors=True)
        sys.exit(f"렌더링 중단: 장면 {missing} 영상/사진 소스 없음. 해당 장면의 keywords를 구체적인 영어 명사로 바꾸거나 image_prompt 또는 media를 넣으세요. (그라데이션 대체를 허용하려면 --allow-fallback)")
    total = t0
    if total > 60:
        log(f"경고: 총 길이 {total:.1f}초 — 60초 이하가 쇼츠에 가장 유리합니다.")

    (work / "videos.txt").write_text("".join(f"file '{p.name}'\n" for p in scene_videos), encoding="utf-8")
    (work / "audios.txt").write_text("".join(f"file '{p.name}'\n" for p in scene_audios), encoding="utf-8")
    run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", "videos.txt", "-c", "copy", "visual.mp4"], cwd=work)
    run([FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", "audios.txt", "-c:a", "pcm_s16le", "narration.wav"], cwd=work)

    show_title_bar = data.get("show_title", True)
    write_ass(work / "subs.ass", title, cues, total, False) # layout parameter removed

    final = outdir / "final.mp4"
    bgm = pick_bgm(data.get("bgm")) if use_bgm else None
    cmd = [FFMPEG, "-y", "-i", "visual.mp4", "-i", "narration.wav"]
    vf = "[0:v]ass=subs.ass:fontsdir=fonts,format=yuv420p[v]"
    if show_title_bar:
        _, ty = make_title_bar(data.get("title_bar", title), data.get("title_highlight", []), work / "title.png", title_font, is_full=True)
        cmd += ["-i", "title.png"]
        title_idx = 2  # 0: visual.mp4, 1: narration.wav, 2: title.png
        vf = f"[0:v][{title_idx}:v]overlay=x=(W-w)/2:y={ty}[tb];[tb]ass=subs.ass:fontsdir=fonts,format=yuv420p[v]"
    if bgm:
        log(f"배경음악: {bgm.name}")
        bgm_idx = 3 if show_title_bar else 2
        cmd += ["-stream_loop", "-1", "-i", str(bgm)]
        fc = (f"{vf};[{bgm_idx}:a]volume={data.get('bgm_volume', 0.12)},afade=t=out:st={max(total - 1.5, 0):.2f}:d=1.5[b];"
              "[1:a][b]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]")
    else:
        fc = f"{vf};[1:a]anull[a]"
    cmd += ["-filter_complex", fc, "-map", "[v]", "-map", "[a]", "-t", f"{total:.3f}"]
    tail = ["-r", str(FPS), "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(final.resolve())]
    # Intel 내장 GPU(Quick Sync) 하드웨어 인코딩: CPU x264 medium 대비 약 4배 빠름. 실패하면 CPU로 자동 전환.
    qsv = ["-c:v", "h264_qsv", "-global_quality", "21", "-preset", "veryfast", "-pix_fmt", "nv12"]
    cpu = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p"]
    log("최종 렌더링 중 (하드웨어 인코딩)...")
    proc = subprocess.run(cmd + qsv + tail, cwd=work, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if proc.returncode != 0:
        log("하드웨어 인코딩 실패 → CPU 인코딩으로 재시도")
        run(cmd + cpu + tail, cwd=work)

    preview = make_preview(final, total, outdir / "compressed.mp4")
    log(f"텔레그램용 경량본: {preview} ({preview.stat().st_size / 1048576:.1f}MB)")
    meta = {
        "preview": str(preview),
        "layout": "full",
        "qa": {"dark_scenes": dark},
        "title": title,
        "description": data.get("description", ""),
        "tags": data.get("tags", []),
        "duration_sec": round(total, 2),
        "video": str(final),
        "created": stamp,
        "credits": CREDITS,
    }
    (outdir / "metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    if not os.getenv("SHORTS_KEEP_WORK"):
        shutil.rmtree(work, ignore_errors=True)
    log(f"완료! {final} ({total:.1f}초)")
    print(json.dumps(meta, ensure_ascii=False))
    return final


def main() -> None:
    ap = argparse.ArgumentParser(description="script.json으로 유튜브 쇼츠 영상을 만듭니다.")
    ap.add_argument("script", type=Path, help="대본 JSON 경로")
    ap.add_argument("--voice", help="edge-tts 음성 (예: ko-KR-SunHiNeural, ko-KR-InJoonNeural, ko-KR-HyunsuMultilingualNeural)")
    ap.add_argument("--rate", help="말하기 속도 (예: +10%%)")
    ap.add_argument("--no-bgm", action="store_true", help="배경음악 끄기")
    ap.add_argument("--out", type=Path, default=ROOT / "output", help="출력 폴더")
    ap.add_argument("--allow-fallback", action="store_true", help="소스 없는 장면을 그라데이션으로 대체(기본: 렌더링 중단)")
    args = ap.parse_args()
    build(args.script, args.voice, args.rate, not args.no_bgm, args.out, args.allow_fallback)


if __name__ == "__main__":
    main()
