# 10조 니체 쇼츠 화이트라벨 라이선스 패키지

> **완전 자동화된 유튜브 쇼츠 제작 파이프라인** — 대본 JSON만 넣으면 1080x1920 쇼츠 영상이 나옵니다.

---

## 📦 패키지 구성

```
white_label_license/
├── LICENSE                    # MIT 라이선스 + 화이트라벨 부가 조건
├── README.md                  # 이 파일
├── requirements.txt           # Python 의존성
├── scripts/
│   ├── make_short.py          # 메인 파이프라인 (대본 → 최종 MP4)
│   └── gen_image.py           # AI 이미지 생성 (Gemini → Pollinations 폴백)
├── prompts/                   # 니체 철학 9편 완성 대본
│   ├── nietzsche_god_is_dead.json
│   ├── nietzsche_eternal_recurrence.json
│   ├── nietzsche_three_metamorphoses.json
│   ├── nietzsche_amor_fati.json
│   ├── nietzsche_what_doesnt_kill.json
│   ├── nietzsche_others_gaze.json
│   ├── nietzsche_self_value.json
│   ├── nietzsche_solitude.json
│   ├── nietzsche_overman.json
│   ├── nietzsche_meaning_in_suffering.json
│   └── nietzsche_will_to_power.json
├── assets/
│   ├── music/                 # 배경음악 3종 (앰비언트)
│   │   ├── ambient_bright.mp3
│   │   ├── ambient_calm.mp3
│   │   └── ambient_curious.mp3
│   └── fonts/                 # 자막용 폰트 5종
│       ├── malgunbd.ttf       # 맑은 고딕 볼드 (한글 기본)
│       ├── NotoSansKR.ttf     # 구글 노토 산스 KR
│       ├── Pretendard-Black.otf
│       ├── Pretendard-Bold.otf
│       └── Pretendard-ExtraBold.otf
└── config/
    └── .env.template          # 환경 변수 템플릿
```

---

## 🚀 빠른 시작

### 1. 의존성 설치

```bash
# Python 3.11+ 권장
python -m venv .venv
.venv\Scripts\activate      # Windows
# source .venv/bin/activate  # macOS/Linux

pip install -r requirements.txt
```

### 2. 필수 도구 설치

| 도구 | 설치 방법 |
|------|-----------|
| **FFmpeg** | `winget install Gyan.FFmpeg` (Windows) / `brew install ffmpeg` (macOS) / `apt install ffmpeg` (Ubuntu) |
| **edge-tts** | `pip install edge-tts` (requirements.txt에 포함) |

### 3. 환경 변수 설정

```bash
cp config/.env.template config/.env
# config/.env 편집 - 필요 키만 채우면 됨
```

**필수 키 (선택사항, 없으면 무료 소스 자동 사용):**
- `PEXELS_API_KEY` — 고화질 스톡 영상용 (무료 발급: pexels.com)
- `GEMINI_API_KEY` — 고품질 AI 이미지 생성용 (Google AI Studio에서 발급)

**기본값으로도 동작함** (Pexels 키 없음 → Openverse 무료 사진, Gemini 키 없음 → Pollinations 무료 생성)

### 4. 첫 영상 만들기

```bash
# 9편 중 아무거나 실행
python scripts/make_short.py prompts/nietzsche_god_is_dead.json

# 옵션 예시
python scripts/make_short.py prompts/nietzsche_eternal_recurrence.json --voice ko-KR-InJoonNeural --rate +15% --no-bgm
```

**출력:** `output/YYYYMMDD_HHMMSS_제목/` 폴더에 `final.mp4` (원본), `compressed.mp4` (텔레그램용 5MB 이하), `metadata.json` 생성

---

## 🎬 대본 JSON 구조

```json
{
  "title": "영상 제목",
  "description": "유튜브 설명란용",
  "tags": ["태그1", "태그2"],
  "voice": "ko-KR-HyunsuMultilingualNeural",
  "rate": "+10%",
  "show_title": true,
  "bgm": "ambient_calm.mp3",
  "bgm_volume": 0.12,
  "image_style": "cinematic, dramatic lighting, 9:16",
  "scenes": [
    { "text": "나레이션 텍스트", "keywords": ["pexels 검색어1", "검색어2"] },
    { "text": "다음 장면", "image_prompt": "AI 이미지 생성 프롬프트" }
  ]
}
```

**장면 필드:**
- `text` (필수): TTS로 읽힐 나레이션
- `keywords`: Pexels/Openverse 검색어 (영어 명사 권장)
- `image_prompt`: AI 이미지 생성용 프롬프트 (keywords 대신 사용)
- `media`: 로컬 이미지/영상 경로 (최우선 사용)

---

## ⚙️ 고급 옵션

```bash
python scripts/make_short.py script.json \
  --voice ko-KR-SunHiNeural \      # 음성 변경
  --rate +20% \                     # 속도 변경
  --no-bgm \                        # 배경음악 끄기
  --allow-fallback \                # 소스 없으면 그라데이션 배경으로 대체
  --out ./my_output                 # 출력 폴더 지정
```

**지원 음성 (Edge-TTS 한국어):**
- `ko-KR-SunHiNeural` (기본, 여성 차분)
- `ko-KR-InJoonNeural` (남성 중저음)
- `ko-KR-HyunsuMultilingualNeural` (남성 다국어, 추천)
- `ko-KR-BongJinNeural` (남성 밝음)
- `ko-KR-JiMinNeural` (여성 밝음)

---

## 🎨 자막 스타일 커스터마이징

`make_short.py` 내 `write_ass()` 함수의 Style 섹션 수정:

```python
# 폰트 크기, 색상, 위치, 외곽선 등 변경 가능
Style: Sub,Malgun Gothic,88,&H00FFFFFF,&H0000FFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,6,2,2,70,70,280,1
#                           ↑흰색      ↑노란색강조  ↑검은외곽  ↑반투명배경  ↑외곽선두께  ↑그림자  ↑정렬(중앙하단) ↑여백
```

**9가지 스타일 프리셋** (대본의 `font` 필드로 선택):
- `Malgun Gothic` (기본)
- `Pretendard` (모던 산세리프)
- `Noto Sans KR` (구글 표준)

---

## 🔧 FFmpeg 인코딩 프리셋

`make_short.py`에서 두 가지 경로 자동 선택:

| 경로 | 설정 | 용도 |
|------|------|------|
| **하드웨어 (QSV)** | `-c:v h264_qsv -global_quality 21 -preset veryfast` | Intel 내장 GPU (기본, 4배 빠름) |
| **CPU 폴백** | `-c:v libx264 -preset veryfast -crf 21` | QSV 실패 시 자동 전환 |

**수동 지정:** 코드 내 `qsv` / `cpu` 리스트 수정

---

## 📋 9편 니체 쇼츠 대본 목록

| 파일 | 제목 | 핵심 키워드 |
|------|------|-------------|
| `nietzsche_god_is_dead.json` | 니체가 말하는 '신은 죽었다'의 진짜 의미 | 무신론 아님, 기준 붕괴, 초인 |
| `nietzsche_eternal_recurrence.json` | 영원 회귀: 삶을 무한히 반복한다면 | 사고실험, 후회 없는 삶 |
| `nietzsche_three_metamorphoses.json` | 인생 3단계: 낙타→사자→아이 | 정신 진화, 창조적 삶 |
| `nietzsche_amor_fati.json` | 아모르 파티: 운명을 사랑하라 | 고통 수용, 운명애 |
| `nietzsche_what_doesnt_kill.json` | 나를 죽이지 못한 건 날 강하게 만든다 | 시련 극복, 회복탄력성 |
| `nietzsche_others_gaze.json` | 타인의 시선에서 벗어나는 법 | 자유, 주체성, 노예 도덕 |
| `nietzsche_self_value.json` | 당신의 가치는 당신이 정한다 | 자존감, 자기 결정권 |
| `nietzsche_solitude.json` | 고독: 위대한 자는 혼자 걷는다 | 고독의 가치, 무리 본능 |
| `nietzsche_overman.json` | 초인(위버멘쉬): 인간은 건너야 할 다리 | 자기 극복, 창조 |
| `nietzsche_meaning_in_suffering.json` | 고통에 의미를 부여하라 | 의미 치료, 킨츠기 |
| `nietzsche_will_to_power.json` | 힘에의 의지: 삶의 근본 에너지 | 성장 본능, 자기 초월 |

> 총 12편 (일부 중복 주제 별도 파일 존재). 필요에 따라 골라 쓰세요.

---

## 📝 라이선스 요약

| 권한 | 포함 여부 |
|------|-----------|
| 상업적 이용 | ✅ 무제한 |
| 수정·파생작 | ✅ 무제한 |
| 배포·재판매 | ✅ 무제한 (원저작자 표기 유지) |
| 브랜드 제거 | ✅ 자유 |
| 기술 지원 | ❌ 별도 계약 |
| 특허 보장 | ❌ MIT 표준 |

**전문:** `LICENSE` 파일 참조

---

## ❓ 문제 해결

| 증상 | 원인 | 해결 |
|------|------|------|
| `ffmpeg not found` | FFmpeg 미설치/경로 미등록 | `winget install Gyan.FFmpeg` 후 재시작 |
| `edge-tts` 실패 | 네트워크/지역 차단 | VPN 또는 `--voice` 옵션으로 다른 음성 시도 |
| 영상 소스 없음 | Pexels 키 없음 + 검색어 매칭 실패 | `keywords`를 구체적 영어 명사로, 또는 `image_prompt` 사용 |
| 너무 어두운 영상 | 스톡 영상 밝기 낮음 | `--allow-fallback` 또는 `image_prompt`로 밝은 이미지 지정 |
| 한글 깨짐 | 콘솔 인코딩 | `chcp 65001` (Windows) 또는 터미널 UTF-8 설정 |

---

## 🔄 업데이트/커스텀 가이드

1. **새 대본 추가**: `prompts/`에 JSON 파일 생성 → `python scripts/make_short.py prompts/new.json`
2. **자막 스타일 변경**: `make_short.py`의 `write_ass()` Style 섹션 편집
3. **새 배경음악**: `assets/music/`에 mp3 추가 → 대본에 `"bgm": "파일명.mp3"`
4. **폰트 추가**: `assets/fonts/`에 .ttf/.otf 복사 → 대본에 `"font": "폰트명"`
5. **파이프라인 확장**: `make_short.py`의 `build()` 함수 수정 (장면 전환 효과, 인트로/아웃트로 등)

---

## 📞 문의

**10조 비상위원회 수석 B (상품/제작)**
- 패키지 버전: 1.0.0 (2026-10-22)
- 기반: `make_short.py` 파이프라인 검증 완료 (니체 쇼츠 9편 제작 이력)

---
*본 패키지는 10조 공식 채널을 통해 구매한 정품 구매자에게만 제공됩니다.*