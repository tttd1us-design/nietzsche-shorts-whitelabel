"""장면용 일러스트 이미지 생성.

순서: Gemini 이미지 모델(결제 등록 시 고품질·워터마크 없음) → Pollinations(무료, 키 불필요, 워터마크 있음).
Pollinations 워터마크는 서비스 조건이므로 잘라내지 않는다.

사용법:
    python scripts/gen_image.py "프롬프트" out.jpg [--aspect 4:3]
"""
from __future__ import annotations

import argparse
import base64
import os
import sys
import time
import urllib.parse
from pathlib import Path

import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / "config" / ".env")
load_dotenv(Path(os.getenv("HERMES_HOME", r"D:\hermes")) / ".env")

GEMINI_IMAGE_MODELS = ["gemini-3.1-flash-image", "gemini-2.5-flash-image"]
SIZES = {"4:3": (1024, 768), "3:4": (768, 1024), "9:16": (720, 1280), "16:9": (1280, 720), "1:1": (1024, 1024)}
_gemini_disabled = False
POLL_MIN_INTERVAL = 16  # 초
_last_poll = 0.0  # 한 번 한도/결제 오류가 나면 이번 실행에서는 다시 시도하지 않음


def _gemini(prompt: str, out: Path, aspect: str) -> bool:
    global _gemini_disabled
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key or _gemini_disabled:
        return False
    for model in GEMINI_IMAGE_MODELS:
        try:
            r = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
                json={"contents": [{"parts": [{"text": prompt}]}],
                      "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": aspect}}},
                timeout=120)
            d = r.json()
        except Exception:
            continue
        if "error" in d:
            if d["error"].get("code") in (429, 403):
                _gemini_disabled = True
                return False
            continue
        for part in d.get("candidates", [{}])[0].get("content", {}).get("parts", []):
            if "inlineData" in part:
                out.write_bytes(base64.b64decode(part["inlineData"]["data"]))
                return True
    return False


def _pollinations(prompt: str, out: Path, aspect: str, seed: int) -> bool:
    w, h = SIZES.get(aspect, (1024, 768))
    # Pollinations no-logo mode can require paid credits; use the free endpoint and preserve any provider mark.
    url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width={w}&height={h}&seed={seed}"
    global _last_poll
    for attempt in range(5):
        wait = POLL_MIN_INTERVAL - (time.time() - _last_poll)  # 무료 이용은 연속 요청 제한이 있음
        if wait > 0:
            time.sleep(wait)
        try:
            _last_poll = time.time()
            r = requests.get(url, timeout=180)
            if r.status_code == 200 and r.headers.get("content-type", "").startswith("image/") and len(r.content) > 20_000:
                out.write_bytes(r.content)
                return True
        except Exception:
            pass
        time.sleep(5 * (attempt + 1))
    return False


def generate(prompt: str, out: Path, aspect: str = "4:3", seed: int = 1) -> str | None:
    """이미지를 out 경로에 저장하고 사용한 제공자 이름을 반환. 실패하면 None."""
    full = f"{prompt}. No text, no letters, no watermark text in the image."
    if _gemini(full, out, aspect):
        return "gemini"
    if _pollinations(full, out, aspect, seed):
        return "pollinations"
    return None


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("prompt")
    ap.add_argument("out", type=Path)
    ap.add_argument("--aspect", default="4:3", choices=list(SIZES))
    a = ap.parse_args()
    provider = generate(a.prompt, a.out, a.aspect)
    print(f"{provider or 'FAILED'}: {a.out}")
    sys.exit(0 if provider else 1)
